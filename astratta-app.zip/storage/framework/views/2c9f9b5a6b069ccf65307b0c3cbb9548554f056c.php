<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="https://arteastratta.es/public/frontend/images/logo.png" class="logo" alt="Astratta Logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>