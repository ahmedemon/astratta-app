<?php $__env->startSection('content'); ?>
    <div class="container-fluid mt-5">
        <h1 class="my-0">Welcome To Dashboard</h1>
        <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class=""><?php echo e($wallets_name[$key]); ?>: <?php echo e(config('currency.usd') . $wallet); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.app', ['pageTitle' => $pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>