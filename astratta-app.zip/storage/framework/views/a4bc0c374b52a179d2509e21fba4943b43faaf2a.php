                    <div class="col-md-3 profile-section bg-white">
                        <div class="profile-info-section">
                            <h1 class="my-0 mb40-important">Hello <?php echo e(strtok(Auth::user()->name, ' ')); ?>,</h1>
                            <p class="my-0 mb10-important"><?php echo e(date('h:i:s')); ?></p>
                            <p class="my-0 mb40-important">May 27, 2022</p>
                            <a href="<?php echo e(route('logout')); ?>" class="btn rounded-0 sign-in-button logout mb45" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                        <hr class="mb50-important" />
                        <div class="row mx-auto profile-product-section">
                            <div class="col-md-12 d-flex align-items-center px-lg-0 px-xl-0 px-xxl-0 mb40">
                                <img src="<?php echo e(asset('frontend/images/art/demo3.png')); ?>" alt="" />
                                <a href="<?php echo e(route('painting.show', 1)); ?>" class="">La Réunion Acryilic</a>
                            </div>
                            <div class="col-md-12 d-flex align-items-center px-lg-0 px-xl-0 px-xxl-0">
                                <img src="<?php echo e(asset('frontend/images/art/demo3.png')); ?>" alt="" />
                                <a href="<?php echo e(route('painting.show', 1)); ?>" class="">La Réunion Acryilic</a>
                            </div>
                        </div>
                    </div>
<?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/frontend/my-account/side-menu.blade.php ENDPATH**/ ?>