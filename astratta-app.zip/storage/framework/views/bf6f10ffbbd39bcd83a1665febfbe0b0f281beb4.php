<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>
    <img height="50px" src="https://arteastratta.es/public/frontend/images/logo.png" alt="">
    <h1>Welcome To <?php echo e(config('app_name')); ?></h1>
    <h2>Hello <?php echo e($user->username); ?>, Account created successfully</h2>
    <a href="<?php echo e(route('home')); ?>">Go To Website</a>
</body>

</html>
<?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/newUserGreetings.blade.php ENDPATH**/ ?>