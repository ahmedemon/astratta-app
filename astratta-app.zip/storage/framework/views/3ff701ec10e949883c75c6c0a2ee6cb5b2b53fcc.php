<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-0 bg-light">
        <div class="container px-lg-0 px-xl-0 px-xxl-0 pt96 pb96 vendor-section">
            <div class="row justify-content-between mx-auto">
                <?php echo $__env->make('layouts.seller.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-md-12 col-lg-8 col-xl-8 col-xxl-8 col-12 vendor-content">
                    <button class="btn btn-light sideMenuButton d-lg-none d-xl-none d-xxl-none" onclick="sideBarToggle()"><i class="fas fa-arrow-right"></i></button>
                    <h3 class="my-0 d-flex align-items-center justify-content-between mb35-i">
                        Add New Product <a href="<?php echo e(route('seller.product.index')); ?>" class="text-decoration-none text-dark"><i class="fas fa-times"></i></a>
                    </h3>
                    <form method="POST" action="<?php echo e(route('seller.product.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row mb35">
                            <div class="avatar-upload text-center">
                                <div class="avatar-edit">
                                    <input type="file" id="imageUpload-0" name="main_image" accept=".png, .jpg, .jpeg" class="imageUpload-0" onclick="productImage0();" />
                                    <input type="hidden" id="base_image_data-0" name="base64image1" />
                                    <label for="imageUpload-0" class="d-flex justify-content-center align-items-center"><i class="lni lni-plus"></i></label>
                                </div>
                                <div class="avatar-preview">
                                    <div id="imagePreview-0" style="background-image: url('<?php echo e(asset('')); ?>')"></div>
                                </div>
                                <label for="image" class="small">Main Image</label>
                            </div>
                        </div>
                        <div class="row mb35">
                            <div class="avatar-upload text-center">
                                <div class="avatar-edit">
                                    <input type="file" id="imageUpload-1" name="image" accept=".png, .jpg, .jpeg" class="imageUpload-1" onclick="productImage1();" />
                                    <input type="hidden" id="base_image_data-1" name="base64image[]" />
                                    <label for="imageUpload-1" class="d-flex justify-content-center align-items-center"><i class="lni lni-plus"></i></label>
                                </div>
                                <div class="avatar-preview">
                                    <div id="imagePreview-1" style="background-image: url('<?php echo e(asset('')); ?>')"></div>
                                </div>
                                <label for="image" class="small">First Image</label>
                            </div>
                            <div class="avatar-upload text-center">
                                <div class="avatar-edit">
                                    <input type="file" id="imageUpload-2" name="image" accept=".png, .jpg, .jpeg" class="imageUpload-2" onclick="productImage2();" />
                                    <input type="hidden" id="base_image_data-2" name="base64image[]" />
                                    <label for="imageUpload-2" class="d-flex justify-content-center align-items-center"><i class="lni lni-plus"></i></label>
                                </div>
                                <div class="avatar-preview">
                                    <div id="imagePreview-2" style="background-image: url('<?php echo e(asset('')); ?>')"></div>
                                </div>
                                <label for="image" class="small">Second Image</label>
                            </div>
                            <div class="avatar-upload text-center">
                                <div class="avatar-edit">
                                    <input type="file" id="imageUpload-3" name="image" accept=".png, .jpg, .jpeg" class="imageUpload-3" onclick="productImage3();" />
                                    <input type="hidden" id="base_image_data-3" name="base64image[]" />
                                    <label for="imageUpload-3" class="d-flex justify-content-center align-items-center"><i class="lni lni-plus"></i></label>
                                </div>
                                <div class="avatar-preview">
                                    <div id="imagePreview-3" style="background-image: url('<?php echo e(asset('')); ?>')"></div>
                                </div>
                                <label for="image" class="small">Third Image</label>
                            </div>
                        </div>

                        <div class="mb35">
                            <input type="text" name="product_name" value="<?php echo e(old('product_name')); ?>" placeholder="Product Name" class="form-control <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <small><?php echo e($message); ?></small>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb35">
                            <input type="number" name="product_price" value="<?php echo e(old('product_price')); ?>" placeholder="Price In Doller" class="form-control <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                            <?php $__errorArgs = ['product_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <small><?php echo e($message); ?></small>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb35">
                            <select name="category_id" value="<?php echo e(old('category_id')); ?>" id="" class="form-control">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($loop->first ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <small><?php echo e($message); ?></small>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb35">
                            <select name="tags[]" id="" class="form-control tags <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" aria-placeholder="tags">
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($tag->name); ?>"><?php echo e($tag->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <small><?php echo e($message); ?></small>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb35">
                            <textarea type="text" name="about_this_paint" placeholder="About this paint" class="form-control <?php $__errorArgs = ['about_this_paint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                            <?php $__errorArgs = ['about_this_paint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <small><?php echo e($message); ?></small>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row">
                            <div class="mb35 col-md-6 col-lg-6 col-xl-6 col-xxl-6 col-12">
                                <textarea type="text" name="details_1" placeholder="Details Column 1" class="form-control <?php $__errorArgs = ['details_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                                <?php $__errorArgs = ['details_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <small><?php echo e($message); ?></small>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb35 col-md-6 col-lg-6 col-xl-6 col-xxl-6 col-12">
                                <textarea type="text" name="details_2" placeholder="Details Column 2" class="form-control <?php $__errorArgs = ['details_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                                <?php $__errorArgs = ['details_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <small><?php echo e($message); ?></small>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <button class="btn sign-up-button rounded">Create Product</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        $(function() {
            $(".tags").select2({
                tags: true,
                multiple: true,
            });
        });
        $(".sign-up-button").click(function() {
            if (!$("#imageUpload-1").val() || !$("#imageUpload-2").val() || !$("#imageUpload-3").val()) {
                return confirm('Update without images?');
                if ($("#imageUpload-1").val() && !$("#imageUpload-2").val()) {
                    swal("Please select second image!", "", "warning");
                }
                if ($("#imageUpload-2").val() && !$("#imageUpload-3").val()) {
                    swal("Please select first image!", "", "warning");
                }
                if ($("#imageUpload-3").val() && !$("#imageUpload-2").val()) {
                    swal("Please select second image!", "", "warning");
                }
                if ($("#imageUpload-3").val() && $("#imageUpload-2").val() && !$("#imageUpload-1").val()) {
                    swal("Please select first image!", "", "warning");
                }
                if ($("#imageUpload-1").val() && $("#imageUpload-2").val() && !$("#imageUpload-3").val()) {
                    swal("Please select third image!", "", "warning");
                }
                if ($("#imageUpload-1").val() && $("#imageUpload-3").val() && !$("#imageUpload-2").val()) {
                    swal("Please select second image!", "", "warning");
                }
            }
        });

        function productImage0() {
            function readURL(input0) {
                if (input0.files && input0.files[0]) {
                    var reader0 = new FileReader();
                    reader0.onload = function(e) {
                        $('#imagePreview-0').css('background-image', 'url(' + e.target.result + ')');
                        $('#imagePreview-0').hide();
                        $('#imagePreview-0').fadeIn(650);

                        var base64data0 = reader0.result;
                        $('#base_image_data-0').val(base64data0);
                    }
                    reader0.readAsDataURL(input0.files[0]);
                }
            }
            $("#imageUpload-0").change(function() {
                readURL(this);
            });
        }

        function productImage1() {
            function readURL(input1) {
                if (input1.files && input1.files[0]) {
                    var reader1 = new FileReader();
                    reader1.onload = function(e) {
                        $('#imagePreview-1').css('background-image', 'url(' + e.target.result + ')');
                        $('#imagePreview-1').hide();
                        $('#imagePreview-1').fadeIn(650);

                        var base64data1 = reader1.result;
                        $('#base_image_data-1').val(base64data1);
                    }
                    reader1.readAsDataURL(input1.files[0]);
                }
            }
            $("#imageUpload-1").change(function() {
                readURL(this);
            });
        }

        function productImage2() {
            function readURL(input2) {
                if (input2.files && input2.files[0]) {
                    var reader2 = new FileReader();
                    reader2.onload = function(e) {
                        $('#imagePreview-2').css('background-image', 'url(' + e.target.result + ')');
                        $('#imagePreview-2').hide();
                        $('#imagePreview-2').fadeIn(650);

                        var base64data2 = reader2.result;
                        $('#base_image_data-2').val(base64data2);
                    }
                    reader2.readAsDataURL(input2.files[0]);
                }
            }
            $("#imageUpload-2").change(function() {
                readURL(this);
            });
        }

        function productImage3() {
            function readURL(input3) {
                if (input3.files && input3.files[0]) {
                    var reader3 = new FileReader();
                    reader3.onload = function(e) {
                        $('#imagePreview-3').css('background-image', 'url(' + e.target.result + ')');
                        $('#imagePreview-3').hide();
                        $('#imagePreview-3').fadeIn(650);

                        var base64data3 = reader3.result;
                        $('#base_image_data-3').val(base64data3);
                    }
                    reader3.readAsDataURL(input3.files[0]);
                }
            }
            $("#imageUpload-3").change(function() {
                readURL(this);
            });
        }
    </script>
    <script>
        <?php if(count($errors) > 0): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error("<?php echo e($error); ?>");
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.seller.app', ['pageTitle' => $pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/seller/product/form.blade.php ENDPATH**/ ?>