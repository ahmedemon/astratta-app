[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>