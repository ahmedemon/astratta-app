<h1>Welcome To <?php echo e(config('app_name')); ?></h1>
<p>To Reset your password <a href="<?php echo e(route('seller.reset.password', $token)); ?>">Click Here</a></p>
<?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/email/seller-reset-link.blade.php ENDPATH**/ ?>