<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-0 bg-light">
        <div class="container px-lg-0 px-xl-0 px-xxl-0 pt96 pb96 vendor-section">
            <div class="row justify-content-between mx-auto">
                <?php echo $__env->make('layouts.seller.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-md-8 col-lg-8 col-xl-8 col-xxl-8 col-12 vendor-content">
                    <button class="btn btn-light sideMenuButton d-lg-none d-xl-none d-xxl-none" onclick="sideBarToggle()"><i class="fas fa-arrow-right"></i></button>
                    <div class="card mb30 border-0">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <h3 class="my-0"><?php echo e($pageTitle); ?></h3>
                            <a href="<?php echo e(route('seller.withdraw.create')); ?>" class="btn btn-sm rounded-0 pb-0 sign-in-button mx-0 h-50">Add New</a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table class="table table-borderless" style="width: 100%">
                                <thead class="mb30-i">
                                    <tr>
                                        <th class="align-middle active">Amount</th>
                                        <th class="align-middle active text-center">Method</th>
                                        <th class="align-middle active text-center">Status</th>
                                        <th class="align-middle active text-center">Date</th>
                                        <th class="align-middle active text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="data-row">
                                            <td class="align-middle"><?php echo e('$' . str_replace('.00', '', $withdraw->amount)); ?></td>
                                            <td class="align-middle text-center"><?php echo e($withdraw->withdrawMethod->name ?? '--'); ?></td>
                                            <td class="align-middle text-center">
                                                <?php echo e(($withdraw->status == 0 ? 'Processing' : '') . ($withdraw->status == 1 ? 'Processing' : '') . ($withdraw->status == 2 ? 'Complete' : '') . ($withdraw->status == 3 ? 'Rejected' : '')); ?>

                                            </td>
                                            <td class="align-middle text-center"><?php echo e($withdraw->created_at->format('M:d:Y')); ?></td>
                                            <td class="align-middle text-center">
                                                <a href="javascript:void();" class="text-success"><i class="fas fa-check"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($withdraws->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.seller.app', ['pageTitle' => $pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/seller/withdraw/index.blade.php ENDPATH**/ ?>