<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-0 bg-light">
        <div class="container px-lg-0 px-xl-0 px-xxl-0 pt96 pb96 vendor-section">
            <div class="row justify-content-between mx-auto">
                <?php echo $__env->make('layouts.seller.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-md-8 col-lg-8 col-xl-8 col-xxl-8 col-12 vendor-content">
                    <button class="btn btn-light sideMenuButton d-lg-none d-xl-none d-xxl-none" onclick="sideBarToggle()"><i class="fas fa-arrow-right"></i></button>
                    <div class="card-body d-flex align-items-center justify-content-between mb30 pb10 border-bottom">
                        <h3 class="my-0"><?php echo e($pageTitle); ?></h3>
                        <a href="<?php echo e(route('seller.withdraw.index')); ?>" class="btn btn-sm rounded-0 pb-0 sign-in-button mx-0 h-50">Go Back</a>
                    </div>
                    <?php if(count($errors) > 0): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <small class="text-danger"><?php echo e($error); ?></small>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <form action="<?php echo e(route('seller.withdraw.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-center">
                            <div class="col-md-8">
                                <?php $__currentLoopData = $wallets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $wallet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->iteration == 1): ?>
                                        <h3 class="my-0"><?php echo e($wallet_name[$key]); ?> - $<?php echo e($wallet); ?></h3>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <br>
                                <div class="mb20">
                                    <label for="amount">Payment Method</label>
                                    <div class="input-group">
                                        <select name="method_id" class="form-control form-select" id="selector" onchange="yesnoCheck(this);">
                                            <?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($method->id); ?>"><?php echo e($method->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <small><?php echo e($message); ?></small>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb20">
                                    <label for="amount"> Account Number </label>
                                    <input type="number" name="account_number" class="form-control" placeholder="Enter account number">
                                    <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <small><?php echo e($message); ?></small>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="mb20">
                                    <label for="amount"> Withdrawal Amount </label>
                                    <div class="input-group">
                                        <input type="number" min="0" id="amount" name="amount" class="form-control rounded-0" />
                                        <button class="btn btn-outline-secondary btn-sm px-3" type="submit">Submit</button>
                                    </div>
                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <small><?php echo e($message); ?></small>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        function yesnoCheck(that) {
            if (that.value == "1") {
                document.getElementById("1").className = "mb20 d-block";
            } else {
                document.getElementById("1").className = "mb20 d-none";
            }
            if (that.value == "2") {
                document.getElementById("2").className = "mb20 d-block";
            } else {
                document.getElementById("2").className = "mb20 d-none";
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.seller.app', ['pageTitle' => $pageTitle], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/seller/withdraw/create.blade.php ENDPATH**/ ?>