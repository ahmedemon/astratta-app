


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>

<body>
    <table>
        <tr>
            <td>Name: </td>
            <td><?php echo e($contacts['name']); ?></td>
        </tr>
        <tr>
            <td>Phone: </td>
            <td><?php echo e($contacts['phone']); ?></td>
        </tr>
        <tr>
            <td>Subject: </td>
            <td><?php echo e($contacts['subject']); ?></td>
        </tr>
        <tr>
            <td>Email: </td>
            <td><?php echo e($contacts['email']); ?></td>
        </tr>
        <tr>
            <td>Message: </td>
            <td><?php echo e($contacts['message']); ?></td>
        </tr>
    </table>
</body>

</html>
<?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/email/enquiry_email.blade.php ENDPATH**/ ?>