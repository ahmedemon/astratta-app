<?php $__env->startComponent('mail::message'); ?>

    # Welcome to <?php echo e(config('app_name')); ?>


    Hello <?php echo e($seller->username); ?>

    You have been registered as a seller on <?php echo e(config('app_name')); ?>


    <?php $__env->startComponent('mail::button', ['url' => 'https://arteastratta.es/', 'color' => 'success']); ?>
        Go To Website
    <?php echo $__env->renderComponent(); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/email/sellers.blade.php ENDPATH**/ ?>