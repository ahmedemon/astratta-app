<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-0 bg-white d-flex">
        <div class="sign-up-form-section">
            <div class="container px-0">
                <div class="row justify-content-between mx-auto">
                    <div class="form-left-side-container col-lg-8 col-xl-8 col-xxl-8 col-md-12"></div>
                    <div class="form-right-side-container col-lg-4 col-xl-4 col-xxl-4 col-md-12 d-flex justify-content-lg-end pe-lg-0 pe-xl-0 pe-xxl-0">
                        <div class="form-right-side px-0">
                            <h1 class="my-0">Sign Up</h1>
                            <?php if(count($errors) > 0): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <small class="text-danger"><?php echo e($error); ?></small>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <form method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="inputGroup mb30">
                                    <label for="username">Username</label>
                                    <input type="text" id="username" class="px-0 form-control rounded-0 border-0 border-bottom border-secondary shadow-none <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="johndoe" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus />
                                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <small><?php echo e($message); ?></small>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="inputGroup mb30">
                                    <label for="email">Email</label>
                                    <input type="email" id="email" class="px-0 form-control rounded-0 border-0 border-bottom border-secondary shadow-none <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="info@enample.com" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" />
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <small><?php echo e($message); ?></small>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="inputGroup mb30">
                                    <label for="password">Password</label>
                                    <input type="password" id="password" class="px-0 form-control rounded-0 border-0 border-bottom border-secondary shadow-none <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter your password" name="password" required autocomplete="new-password" />
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <small><?php echo e($message); ?></small>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="inputGroup mb20">
                                    <label for="password-confirm">Confirm Password</label>
                                    <input type="password" id="password-confirm" class="px-0 form-control rounded-0 border-0 border-bottom border-secondary shadow-none" placeholder="Enter your password again" name="password_confirmation" required autocomplete="new-password" />
                                </div>
                                <div class="inputGroup form-check mb30">
                                    <div class="d-flex align-items-center">
                                        <input type="checkbox" class="form-check-input" id="privacy_policy" name="privacy_policy" value="1" required />
                                        <label class="form-check-label" for="privacy_policy">I agree to the <a href="">privary policy</a></label>
                                    </div>
                                    <?php $__errorArgs = ['privacy_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <small><?php echo e($message); ?></small>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="submit" class="btn rounded-0 border-0 login">CREATE ACCOUNT</button>
                                <a href="<?php echo e(route('login')); ?>" class="sub-link">Sign In Insted</a>
                                <div class="d-flex justify-content-between align-items-center or">
                                    <hr />
                                    <small>Or</small>
                                    <hr />
                                </div>
                                <a href="<?php echo e(route('seller.join-us')); ?>" class="btn rounded-0 sign-in-button create-account">JOIN AS AN ARTIST</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', ['pageTitle' => 'Register'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/auth/register.blade.php ENDPATH**/ ?>