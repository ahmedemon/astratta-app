<?php echo e($slot); ?>

<?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>