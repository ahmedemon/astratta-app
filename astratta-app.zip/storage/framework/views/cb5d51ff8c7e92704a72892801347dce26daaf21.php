<?php $__env->startSection('content'); ?>
        <div class="container-fluid product-view-page-container not-found-page px-0 d-flex align-items-center">
            <div class="container">
                <div class="content d-grid justify-content-center">
                    <img src="<?php echo e(asset('frontend/images/errors/419.png')); ?>" alt="" />
                    <h1>Page Expired</h1>
                    <a href="<?php echo e(route('home')); ?>" class="mx-auto btn rounded-0 shadow-none sign-up-button">Back to home</a>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.app', ['pageTitle' => '419 Page Expired'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\astratta-app\resources\views/errors/419.blade.php ENDPATH**/ ?>