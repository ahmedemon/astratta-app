<h1>Welcome To {{ config('app_name') }}</h1>
<p>To Reset your password <a href="{{ route('admin.reset.password', $token) }}">Click Here</a></p>
