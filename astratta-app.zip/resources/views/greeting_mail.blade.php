<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>
    <h1>Hello {{ $user->name }}, Account created successfully</h1>
</body>

</html>
