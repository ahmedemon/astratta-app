@extends('layouts.backend.app', ['pageTitle' => $pageTitle])
@section('content')
    <div class="container-fluid mt-5">
        <h1 class="my-0">Welcome To Dashboard</h1>
    </div>
@endsection
